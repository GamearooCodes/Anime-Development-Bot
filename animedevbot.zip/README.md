# Anime Development Bot

A bot for tickets applications and more.

## Setup

1. copy config.js.example to a new txt doc and name it config.js

2. fill in the blanks

## Starting

### windows

1. install node.js v16 then run update.bat to install the dependency's
2. to start the bot run the start.bat file

### linux

1. install node.js v16

   > curl -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -
   > sudo apt install nodejs

2. install the dependency's

> npm i

3. start the bot
   > node . or node index.js

## dependency update

1. Delete node modules
2. run update.bat or run npm i
