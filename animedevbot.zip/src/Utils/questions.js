exports.questions = [
    "Team? (Mod, Support)",
    "Age?",
    "Did you read the rules?",
    "Anything We Should Know About You?",
    "Do you understand trial period is 23 days after if seen active or doing a good job you will be passed if not then failed?",
    "Why Do You Want To Work For Anime Development?",
    "What Will Happen if your Caught Breaking Rules?",
    "Whats Your Time Zone?",
    "What do you do if someone raids the server?",
    "The discord gets botted with inappropriate images. What steps do you take to rectify the situation and keep the discord a comfortable place?",
    "There are several people in a voice call but someone is being spoken over several times. How would you handle this situation?",
    "A very sensitive topic (ie. trauma, grief, threats, etc.) is brought up in the discord that can be triggering to others. How would you approach this in the discord chat, twitch chat, and a voice call?",
    "A community member comes to you with concerns for another person's wellbeing. How would you respond to the community member and what would you do for the person who is being worried about?",
    "You have to remove someone's message for making the streamer uncomfortable and they lash out at you, the other moderators, and/or the streamer. What do you do?",
    "An account that is less than a day old joins the Discord or Twitch chat. What steps, if any, would you take?",
    "Someone is making fun of Gamearoo. How would you respond?",
    "Gamearoo believes strongly in second chances. We like to time someone out and give 3 warnings before banning someone. Special circumstances will result in skipping this measure. Are you able to adhere to this guideline?",
    "Would you be willing to take part in an interview should your application be accepted?",
    "Do you have any thoughts, suggestions, questions, or final comments for Gamearoo and the management team to consider?",


]