exports.token = "MTAxMjkyMDY3MjI2MDk4ODk4OA.GEze_-.ciuSNvlraXk2TdzqxHpTYP4WBdC1YXk8StNVVk";
exports.mongourl = "mongodb://localhost:27017/animedevbot";
exports.db = {
    host: "localhost",
    user: 'animedevbot',
    pass: 'Donald2112!',
    db: 'animedevbot',
    port: '3306' // only change if ur mysql port is not default
}
exports.version = "1.0.0";
exports.ram_api = {
    key: "TSVNlWXL3q",
    version: 'v11'
}
exports.beta = true;
exports.devguildId = "605900262581993472";
exports.appschannel = "1012925240101306420";